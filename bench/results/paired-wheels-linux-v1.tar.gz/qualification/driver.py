import hashlib, importlib.util, json, os, statistics, subprocess
from pathlib import Path
root = Path("/home/yonghye/ultrafast-vision-build")
source = Path("/home/yonghye/ultrafast-maskops-resize-roi-v1")
harness = source / "bench/compare_wheels.py"
out = root / "mask-paired-linux-qualification-v1"
out.mkdir(exist_ok=False)
versions = {
 "baseline": (root/"mask-masks-only-linux-clean-v1/bin/python", Path("/home/yonghye/ultrafast-maskops-masks-only-v1"), root/"mask-masks-only-linux-dist-v1/ultrafast_maskops-0.1.0a1-cp312-cp312-linux_x86_64.whl"),
 "candidate": (root/"mask-resize-roi-linux-clean-v1/bin/python", source, root/"mask-resize-roi-linux-dist-v1/ultrafast_maskops-0.1.0a1-cp312-cp312-linux_x86_64.whl"),
}
env = dict(os.environ, OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
records = []
def run(label, name, extra):
 python, src, wheel = versions[label]
 path = out / (name+".json")
 command = [str(python), str(harness), "--root", str(src), "--wheel", str(wheel), "--out", str(path), *extra]
 with (out/(name+".log")).open("x") as log:
  subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
 data = path.read_bytes()
 records.append({"name":name, "command":command, "sha256":hashlib.sha256(data).hexdigest()})
 return json.loads(data)
oracles = {label:run(label, "oracle-"+label, ["--worker","oracle"]) for label in versions}
assert oracles["baseline"]["cases"] == oracles["candidate"]["cases"]
assert oracles["baseline"]["expected"] == oracles["candidate"]["expected"]
for case, operation in [(6,"overlap"),(7,"bounded"),(8,"masks")]:
 for label in versions:
  result = run(label, f"c{case}-{operation}-{label}", ["--worker","measure","--oracle",str(out/("oracle-"+label+".json")),"--case",str(case),"--operation",operation,"--samples","10"])
  assert result["descriptor"] == oracles[label]["descriptor"]
  assert result["case"] == case and result["operation"] == operation
  assert len(result["samples_ns"]) == 10 and min(result["samples_ns"]) > 0
  assert result["median_ns"] == statistics.median(result["samples_ns"])
  assert result["output_hashes"] == oracles[label]["expected"][str(case)][operation]
  assert result["peak_rss_bytes"] > 0
  print("qualified",label,case,operation,flush=True)
# Exercise aggregation with a known constant ratio and an independently formed
# weighted multiset distribution (126 selections instead of 3125 ordered tuples).
spec=importlib.util.spec_from_file_location("comparison",harness)
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
assert module.summary([(2,1)]*5)["paired_bootstrap_ci95"] == [2.0,2.0]
import itertools, math
pairs=[(10,7),(12,8),(15,13),(19,10),(30,20)]
values=[]
for indices in itertools.combinations_with_replacement(range(5),5):
 weight=math.factorial(5)
 for i in range(5): weight//=math.factorial(indices.count(i))
 ratio=statistics.median(pairs[i][0] for i in indices)/statistics.median(pairs[i][1] for i in indices)
 values.extend([ratio]*weight)
assert len(values)==3125
values.sort()
def quantile(p):
 x=p*(len(values)-1); lo=math.floor(x); hi=math.ceil(x)
 return values[lo]*(hi-x)+values[hi]*(x-lo) if lo!=hi else values[lo]
summary=module.summary(pairs)
assert summary["ordered_resamples"]==3125
assert math.isclose(summary["baseline_over_candidate"],15/10)
assert all(math.isclose(a,b,rel_tol=1e-14) for a,b in zip(summary["paired_bootstrap_ci95"],[quantile(.025),quantile(.975)]))
receipt={"scope":"qualification only: two full oracle processes, six subset measurement workers with ten samples each, constant and weighted-multiset aggregate checks; not the full performance matrix", "harness_sha256":hashlib.sha256(harness.read_bytes()).hexdigest(),"script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"records":records,"aggregate_checked":summary}
(out/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print("qualification passed",flush=True)
